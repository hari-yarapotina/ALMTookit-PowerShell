﻿# The Write-Host cmdlet enables you to write messages to the Windows PowerShell console.
Write-Host "In ConnectToTargetCRM"
# Connection String for Source CRM Organization  
$orgConnection = Get-CrmConnection -ConnectionString   "Url=https://sorucecrm.local; 
                                                        Username=crm\user2; 
                                                        Password=password418832492; "                                                                                                            
# import the ALM Toolkit module
$scriptDir = Split-Path $MyInvocation.MyCommand.Path
$modulePath = Join-Path $scriptDir "Adxstudio.Xrm.PowerShell\Adxstudio.Xrm.PowerShell.dll"
# Gets the modules that have been imported into the current session. 
Get-Module
# establish the connection to source crm
$global:connection = $orgConnection 
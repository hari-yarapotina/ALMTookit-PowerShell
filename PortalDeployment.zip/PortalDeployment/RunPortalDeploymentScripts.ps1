﻿# Setting Execution Ploicy as remote Signed In
#Set-ExecutionPolicy RemoteSigned
Get-ExecutionPolicy
# Copy Files From Source to Destination Folder
$scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
#.$scriptDir\CopyWebSiteFiles.ps1
# Export Data From CRM
.$scriptDir\GetPortalDataFromSourceCRM.ps1
# Import Data From CRM
#.$scriptDir\ImportPortalDataToTargetCRM.ps1
﻿# This script copies web site file from source to the target folder
Write-Host "Copying Files"
# Released Source Files
$FileSourceRoot = "C:\Projects\Customer_PortalRelease_081516\"
# Destination Folder for Web Site
$FileDestinationRoot="C:\Projects\Releases\Customer_PortalRelease_081516\"
#Portal Areas to be copied
$arrayAreas = @("Areas","bin","Controls","css","fonts","img","js","MasterPages","Pages","Views","500.aspx","Global.asax","packages.config")
Write-Host "Copying Areas"
for ($i=0; $i -lt $arrayAreas.length; $i++) {
	$absSourcePath= $FileSourceRoot + $arrayAreas[$i]
	$absDestPath= $FileDestinationRoot + $arrayAreas[$i]
	# Force Copy The files into the Server
	Copy-Item $absSourcePath -Destination $absDestPath -Recurse -Force
	}
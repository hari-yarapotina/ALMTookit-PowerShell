﻿$scriptDir = Split-Path $MyInvocation.MyCommand.Path
Import-Module $scriptDir\Adxstudio.Xrm.PowerShell\Adxstudio.Xrm.PowerShell.dll
. $scriptDir\ConnectToSourceCRM.ps1
$org
Write-Host $org
$exportPath = Join-Path $scriptDir "Data"
Write-Host $exportPath
# Create Query to Export Data
$queries = @"
<queries>
  <fetch mapping="logical">
    <entity name="adx_accountaccess">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_ad">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_adplacement">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_licensekey">
      <all-attributes />
    </entity>
  </fetch>
   <fetch mapping="logical">
    <entity name="adx_alertsubscription">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_autonumberingdefinition">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_autonumberingrequest">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_bingmaplookup">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_blogpost">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_blog">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_boolparserequest">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_caseaccess">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_contactaccess">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_contentsnippet">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_dateparserequest">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_entityform">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_entityformmetadata">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_entitylist">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_entitypermission">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_externalidentity">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_identifierrequest">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_invitation">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_inviteredemption">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_melissadataaddresscheck">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pagealert">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pagecomment">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pagecommentrating">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pagenotification">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pagetag">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pagetemplate">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_poll">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_polloption">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pollplacement">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_pollsubmission">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_publishingstate">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_publishingstatetransitionrule">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_rating">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_redirect">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_setting">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_shortcut">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_sitemarker">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_sitesetting">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_tag">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webfile">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webfilelog">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webform">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webformmetadata">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webformstep">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_weblink">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_weblinkset">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webnotificationurl">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webpage">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webpageaccesscontrolrule">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webpagehistory">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webpagelog">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webpagerating">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webrole">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webtemplate">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_website">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_websiteaccess">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_websitebinding">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webrole">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_webtemplate">
      <all-attributes />
    </entity>
  </fetch>
  <fetch mapping="logical">
    <entity name="adx_entitypermission_webrole">
      <all-attributes />
    </entity>
  </fetch>
</queries>
"@
# import the ALM Toolkit module
Import-Module ./Adxstudio.Xrm.PowerShell/Adxstudio.Xrm.PowerShell.dll
# Export CRM Configuration Data --> First line is the default --> Second is the modified to get data based on queries
Export-CrmContent -Connection $connection -OutputPath $exportPath -ExcludeMetadata -Uncompressed -ContentFetchXml $queries 
﻿# The Write-Host cmdlet enables you to write messages to the Windows PowerShell console.
Write-Host "In ConnectToSourceCRM"
# Connection String for Source CRM Organization  
$orgConnection = Get-CrmConnection -ConnectionString   "Url=https://targetcrm.local; 
                                                        Username=crm\user1; 
                                                        Password=pafdf2; "                                                        
# import the ALM Toolkit module
$scriptDir = Split-Path $MyInvocation.MyCommand.Path
$modulePath = Join-Path $scriptDir "Adxstudio.Xrm.PowerShell\Adxstudio.Xrm.PowerShell.dll"
# Gets the modules that have been imported into the current session. 
Get-Module
# establish the connection to source crm
$global:connection = $orgConnection 
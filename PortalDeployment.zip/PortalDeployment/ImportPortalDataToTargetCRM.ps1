﻿# initialize the $connection  
$scriptDir = Split-Path $MyInvocation.MyCommand.Path
Import-Module $scriptDir\Adxstudio.Xrm.PowerShell\Adxstudio.Xrm.PowerShell.dll
.$scriptDir\ConnectToTargetCRM.ps1
# Get Data in Data Folder
$sourcePath = Join-Path $scriptDir "Data" 
Write-Host "Importing Data"
Import-Module $scriptDir\Adxstudio.Xrm.PowerShell\Adxstudio.Xrm.PowerShell.dll
# Import Data For the Organization
Import-CrmContent -Connection $connection -InputPath $sourcePath -Force -UpdatesEnabled